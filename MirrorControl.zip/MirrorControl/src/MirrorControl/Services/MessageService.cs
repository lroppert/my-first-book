﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using MirrorControl.Configuration;
using SendGrid;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;

namespace MirrorControl.Services
{
    // This class is used by the application to send Email and SMS
    // when you turn on two-factor authentication in ASP.NET Identity.
    // For more details see this link http://go.microsoft.com/fwlink/?LinkID=532713
    public class MessageService : IEmailSender, ISmsSender
    {
        private AppSettings _appSettings;

        public MessageService(IOptions<AppSettings> appSettingsAccessor)
        {
            _appSettings = appSettingsAccessor.Value;
        }

        public Task SendEmailAsync(
            string subject,
            string message,
            string toEmail,
            MailAddress fromMailName = null,
            List<string> toEmails = null,
            List<string> ccEmails = null,
            List<string> bccEmails = null)
        {
            if (fromMailName == null)
            {
                fromMailName = new MailAddress("MagicMirror@roppert.de", "Magic Mirror");
            }

            // Create the email object first, then add the properties.
            SendGridMessage myMessage = new SendGridMessage()
            {
                From = fromMailName,
                Subject = subject,
                Html = message
            };
            if (toEmail != null)
            {
                myMessage.AddTo(toEmail);
            }
            if (toEmails != null)
            {
                myMessage.AddTo(toEmails);
            }
            if (ccEmails != null)
            {
                ccEmails.ForEach(adr => myMessage.AddCc(adr));
            }
            if (bccEmails != null)
            {
                bccEmails.ForEach(adr => myMessage.AddBcc(adr));
            }

            // Create a Web transport, using API Key
            var transportWeb = new Web(_appSettings.SendGridMailSenderKey);

            if (transportWeb != null)
            {
                // Send the email.
                return transportWeb.DeliverAsync(myMessage);
                // NOTE: If your developing a Console Application, use the following so that the API call has time to complete
                // transportWeb.DeliverAsync(myMessage).Wait();
            }
            else
            {
                return Task.FromResult(0);
            }
        }

        public Task SendSmsAsync(string number, string message)
        {
            // Plug in your SMS service here to send a text message.
            return Task.FromResult(0);
        }
    }
}