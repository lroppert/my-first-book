﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MirrorControl.Configuration;
using Microsoft.Extensions.Options;
using Particle.SDK;
using Particle.SDK.Models;

namespace MirrorControl.Services
{
    public class MirrorService : IMirrorService
    {
        private AppSettings _appSettings;
        private bool _loggedIn = false;
        private ParticleDevice _device = null;

        public MirrorService(IOptions<AppSettings> appSettingsAccessor)
        {
            _appSettings = appSettingsAccessor.Value;

            _loggedIn = ParticleCloud.SharedCloud.TokenLoginAsync(_appSettings.ParticleToken).Result;
            _device = ParticleCloud.SharedCloud.GetDeviceAsync(_appSettings.ParticleDeviceId).Result;
        }

        public string DeviceId
        {
            get
            {
                return _appSettings.ParticleDeviceId;
            }
        }

        public string AccessToken
        {
            get
            {
                return _appSettings.ParticleToken;
            }
        }

        public async Task<bool> Notify(FriendLight friendLight, bool state, byte r, byte g, byte b, byte brightnessPercent)
        {
            bool result = false;

            string args = $"off{(int)friendLight}";
            if (state)
            {
                // 1_C00FF00_B80
                var brightHexStr = Convert.ToInt32(Math.Round(brightnessPercent / 100.0 * 255.0)).ToString("X2");
                args = $"{(int)friendLight}_C{r.ToString("X2")}{g.ToString("X2")}{b.ToString("X2")}_B{brightHexStr}";
            }

            if (_device != null)
            {
                try
                {
                    ParticleFunctionResponse fr = await _device.RunFunctionAsync("notify", args);
                    result = fr.ReturnValue == 0;
                }
                catch
                {
                    // TODO: Add some logging
                }
            }

            return result;
        }

        public async Task<bool> SetRunMode(RunMode mode, byte r, byte g, byte b, byte brightnessPercent)
        {
            bool result = false;

            string args = mode.ToString();
            if (mode != RunMode.Off)
            {
                args = ((int)mode).ToString();
                // 1_C00FF00_B80
                var brightHexStr = Convert.ToInt32(Math.Round(brightnessPercent / 100.0 * 255.0)).ToString("X2");
                args += $"_C{r.ToString("X2")}{g.ToString("X2")}{b.ToString("X2")}_B{brightHexStr}";
            }

            if (_device != null)
            {
                try
                {
                    ParticleFunctionResponse fr = await _device.RunFunctionAsync("set-runmode", args);
                    result = fr.ReturnValue == 0;
                }
                catch
                {
                    // TODO: Add some logging
                }
            }

            return result;
        }

        public async Task<string> GetStripStatus()
        {
            string result = string.Empty;

            if (_device != null)
            {
                try
                {
                    ParticleVariableResponse vr = await _device.GetVariableAsync("status-strip");
                    result = vr.Result;
                }
                catch
                {
                    // TODO: Add some logging
                }
            }

            return result;
        }


        public async Task<string> GetLed1Status()
        {
            string result = string.Empty;

            if (_device != null)
            {
                try
                {
                    ParticleVariableResponse vr = await _device.GetVariableAsync("status-led1");
                    result = vr.Result;
                }
                catch
                {
                    // TODO: Add some logging
                }
            }

            return result;
        }

        public async Task<string> GetLed2Status()
        {
            string result = string.Empty;

            if (_device != null)
            {
                try
                {
                    ParticleVariableResponse vr = await _device.GetVariableAsync("status-led2");
                    result = vr.Result;
                }
                catch
                {
                    // TODO: Add some logging
                }
            }

            return result;
        }

    }
}
