﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;

namespace MirrorControl.Services
{
    public interface IEmailSender
    {
        Task SendEmailAsync(
            string subject,
            string message,
            string toEmail,
            MailAddress fromMailName = null,
            List<string> toEmails = null,
            List<string> ccEmails = null,
            List<string> bccEmails = null);
    }
}