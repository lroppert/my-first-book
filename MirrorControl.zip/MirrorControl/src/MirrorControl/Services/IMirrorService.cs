﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MirrorControl.Services
{
    public enum FriendLight { Led1 = 1, Led2 = 2 };
    public enum RunMode { Off = -1, Mode0 = 0, Mode1 = 1, Mode2 = 2, Mode3 = 3, Mode4 = 4, Mode5 = 5 };

    public interface IMirrorService
    {
        string DeviceId { get; }
        string AccessToken { get; }

        Task<bool> Notify(FriendLight friendLight, bool status, byte r, byte g, byte b, byte brightnessPercent);

        Task<bool> SetRunMode(RunMode mode, byte r, byte g, byte b, byte brightnessPercent);

        Task<string> GetStripStatus();

        Task<string> GetLed1Status();

        Task<string> GetLed2Status();

    }
}
