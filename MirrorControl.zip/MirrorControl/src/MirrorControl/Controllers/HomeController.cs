﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MirrorControl.Services;
using Microsoft.ApplicationInsights;
using MirrorControl.ViewModels;
using Microsoft.Extensions.Options;
using MirrorControl.Configuration;

namespace MirrorControl.Controllers
{
    // https://damienbod.com/2015/07/05/visualizing-elasticsearch-watcher-events-using-asp-net-5-signalr-and-angular/

    public class HomeController : Controller
    {
        private AppSettings _appSettings;
        private IEmailSender _emailService;
        private TelemetryClient _telemetryClient;

        public HomeController(
            IOptions<AppSettings> appSettingsAccessor,
            IEmailSender emailService,
            TelemetryClient telemetryClient
            )
        {
            _emailService = emailService;
            _appSettings = appSettingsAccessor.Value;
            _telemetryClient = telemetryClient;
        }

        //[Authorize(Policy = "Owners")]
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Contact(ContactViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var mailTo = new List<string>() { "Lena@roppert.de" };
                    var mailBcc = new List<string>() { "JRoppert@roppert.de" };
                    await _emailService.SendEmailAsync(
                        $"Contact Message from {model.Name} ({model.Email})",
                        model.Message,
                        null,
                        null,
                        mailTo,
                        null,
                        mailBcc);

                    // That will clear the form
                    ModelState.Clear();

                    ViewBag.Message = "Thank you for your feedback! Your mesage was delivered.";
                }
                catch (Exception ex)
                {
                    _telemetryClient.TrackException(ex);
                    ModelState.AddModelError("", "Sorry, we cannot deliver your message currently.");
                }
            }
            return View();
        }

        public IActionResult Error(string s, string h, string m)
        {
            ViewData["Severity"] = s;
            ViewData["Header"] = h;
            ViewData["Message"] = m;

            return View();
        }
    }
}
