﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Auth0.Core;
using Auth0.Core.Collections;
using Auth0.ManagementApi;
using Auth0.ManagementApi.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace MirrorControl.Controllers
{
    public class AccountController : Controller
    {
        private readonly IOptions<OpenIdConnectOptions> _options;

        public AccountController(IOptions<OpenIdConnectOptions> options)
        {
            _options = options;
        }

        // GET: /<controller>/
        public IActionResult Login(string returnUrl = null)
        {
            var lockContext = HttpContext.GenerateLockContext(_options.Value, returnUrl);

            return View(lockContext);
        }

        public IActionResult Register(string returnUrl = "/Account/ConfirmEmail")
        {
            var lockContext = HttpContext.GenerateLockContext(_options.Value, returnUrl);

            return View(lockContext);
        }

        [Authorize]
        public async Task<IActionResult> Logout()
        {
            // Sign the user out of the authentication middleware (i.e. it will clear the Auth cookie)
            await HttpContext.Authentication.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme, new AuthenticationProperties()
            { IsPersistent = false });

            // Redirect the user to the home page after signing out
            return RedirectToAction("Index", "Home");
        }


        [Authorize]
        public IActionResult ChangePassword(string returnUrl = null)
        {
            var lockContext = HttpContext.GenerateLockContext(_options.Value, returnUrl);

            return View(lockContext);
        }

        public IActionResult EmailConfirmed()
        {
            return View();
        }

        public IActionResult ConfirmEmail()
        {
            return View();
        }

        public IActionResult AccessDenied(string returnUrl)
        {
            return RedirectToAction("Error", "Home", new { s = "w", h = "Access denied.", m = $"You are not allowed to access {returnUrl}." });
        }
    }
}
