﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MirrorControl.Services;
using MirrorControl.Configuration;

namespace MirrorControl
{
    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();

            if (env.IsDevelopment())
            {
                // This will push telemetry data through Application Insights pipeline faster, allowing you to view results immediately.
                builder.AddApplicationInsightsSettings(developerMode: true);
            }

            Configuration = builder.Build();
        }

        public IConfigurationRoot Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<AppSettings>(Configuration.GetSection("AppSettings"));

            // Add Application Insights data collection services to the services container.
            services.AddApplicationInsightsTelemetry(Configuration);

            // Add authentication services
            services.AddAuthentication(options => options.SignInScheme = CookieAuthenticationDefaults.AuthenticationScheme);

            // Configure OIDC Options
            services.Configure<OpenIdConnectOptions>(options =>
            {
                options.AutomaticAuthenticate = false;
                options.AutomaticChallenge = false;

                // We need to specify an Authentication Scheme
                options.AuthenticationScheme = "Auth0";

                // Set the authority to your Auth0 domain
                options.Authority = $"https://{Configuration["auth0:domain"]}";

                // Configure the Auth0 Client ID and Client Secret
                options.ClientId = Configuration["auth0:clientId"];
                options.ClientSecret = Configuration["auth0:clientSecret"];

                // Set response type to code
                options.ResponseType = "code";

                // Set the callback path, so Auth0 will call back to http://localhost:5000/signin-auth0
                // Also ensure that you have added the URL as an Allowed Callback URL in your Auth0 dashboard
                options.CallbackPath = new PathString("/signin-auth0");

                // Configure the Claims Issuer to be Auth0
                options.ClaimsIssuer = "Auth0";

                options.Events = new OpenIdConnectEvents
                {
                    OnTicketReceived = context =>
                    {
                        // Get the ClaimsIdentity
                        var identity = context.Principal.Identity as ClaimsIdentity;
                        if (identity != null)
                        {
                            // Add the Name ClaimType. This is required if we want User.Identity.Name to actually return something!
                            if (!context.Principal.HasClaim(c => c.Type == ClaimTypes.Name) && identity.HasClaim(c => c.Type == "name"))
                            {
                                identity.AddClaim(new Claim(ClaimTypes.Name, identity.FindFirst("name").Value));
                            }
                        }

                        return Task.FromResult(0);
                    }
                };

            });

            // Add framework services.
            services.AddMvc();

            services.AddAuthorization(options =>
            {
                options.AddPolicy("Admins", policy => policy.RequireClaim("groups", "admins"));
                options.AddPolicy("Owners", policy => policy.RequireClaim("groups", "owners"));
                options.AddPolicy("Friends", policy => policy.RequireClaim("groups", "r-friends", "l-friends"));
                options.AddPolicy("L-Friends", policy => policy.RequireClaim("groups", "l-friends"));
                options.AddPolicy("R-Friends", policy => policy.RequireClaim("groups", "r-friends"));
                options.AddPolicy("ValidUsers", policy => policy.RequireClaim("groups", "admins", "owners", "r-friends", "l-friends"));
            });

            // Add application services.
            services.AddTransient<IEmailSender, MessageService>();
            services.AddTransient<ISmsSender, MessageService>();
            services.AddSingleton<IMirrorService, MirrorService>();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseBrowserLink();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();

            // Add the cookie middleware
            app.UseCookieAuthentication(new CookieAuthenticationOptions
            {
                AutomaticAuthenticate = true,
                AutomaticChallenge = true,

                LoginPath = new PathString("/Account/Login"),
                LogoutPath = new PathString("/Account/Logout")
            });

            // Configure OIDC middleware
            var options = app.ApplicationServices.GetRequiredService<IOptions<OpenIdConnectOptions>>();
            options.Value.Events =  new OpenIdConnectEvents()
            {
                OnRemoteFailure = OnRemoteFailure,
            };

            app.UseOpenIdConnectAuthentication(options.Value);

            // Track data about exceptions from the application. Should be configured after all error handling middleware in the request pipeline.
            app.UseApplicationInsightsExceptionTelemetry();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }


        private Task OnRemoteFailure(FailureContext context)
        {
            string error = context.Request.Query["error"];

            if (String.Compare(error, "unauthorized", StringComparison.OrdinalIgnoreCase) == 0)
            {
                string errorDescription = context.Request.Query["error_description"];

                if (!string.IsNullOrEmpty(errorDescription))
                {
                    if (String.Compare(errorDescription, "rse-fev", StringComparison.OrdinalIgnoreCase) == 0)
                    {
                        context.HandleResponse();
                        context.Response.Redirect($"/Account/ConfirmEmail");
                        return Task.FromResult(0);
                    }

                    context.HandleResponse();
                    context.Response.Redirect($"/Home/Error?s=e&m={errorDescription}");
                    return Task.FromResult(0);
                }
            }

            context.HandleResponse();
            context.Response.Redirect($"/Home/Error?s=w&m=We are off for maintenance. Please try again later.");
            return Task.FromResult(0);
        }

    }
}
