﻿namespace MirrorControl.Configuration
{
    public class AppSettings
    {
        public string Hint { get; set; }

        public string SendGridMailSenderKey { get; set; }

        public string ParticleToken { get; set; }

        public string ParticleDeviceId { get; set; }
    }
}