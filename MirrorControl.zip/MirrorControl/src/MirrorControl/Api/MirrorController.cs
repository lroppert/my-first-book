﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MirrorControl.Services;
using Microsoft.AspNetCore.Authorization;
using MirrorControl.ApiModels;

// For more information on enabling Web API for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

/*
Microsoft.Web.Mvc.Resources.AtomFeedActionResult
Microsoft.Web.Mvc.Resources.AtomServiceDocumentActionResult
Microsoft.Web.Mvc.Resources.DataContractJsonActionResult
Microsoft.Web.Mvc.Resources.DataContractXmlActionResult
Microsoft.Web.Mvc.Resources.MultiFormatActionResult
Microsoft.Web.Mvc.Resources.ResourceErrorActionResult
System.Web.Mvc.ContentResult
System.Web.Mvc.EmptyResult
System.Web.Mvc.FileResult
System.Web.Mvc.HttpStatusCodeResult
System.Web.Mvc.JavaScriptResult
System.Web.Mvc.JsonResult
System.Web.Mvc.RedirectResult
System.Web.Mvc.RedirectToRouteResult
System.Web.Mvc.ViewResultBase
*/

namespace MirrorControl.Api
{
    [Route("api/[controller]/v1")]
    public class MirrorController : Controller
    {
        private IMirrorService _mirrorService = null;

        public MirrorController(IMirrorService mirrorService)
        {
            _mirrorService = mirrorService;
        }

        [Authorize(Policy = "ValidUsers")]
        [HttpGet]
        [Route("dc")]
        public DeviceCredentials GetDeviceCredentials()
        {
            return new DeviceCredentials()
            {
                deviceId = _mirrorService.DeviceId,
                auth = _mirrorService.AccessToken
            };
        }

        [Authorize(Policy = "ValidUsers")]
        [HttpGet]
        [Route("status")]
        public async Task<MirrorStatus> GetStatus()
        {
            return new MirrorStatus()
            {
                StripStatus = await _mirrorService.GetStripStatus(),
                Led1Status = await _mirrorService.GetLed1Status(),
                Led2Status = await _mirrorService.GetLed2Status()
            };
        }


        [Authorize(Policy = "Friends")]
        [HttpPost]
        [Route("Notify")]
        public async Task<ApiResult> Notify([FromBody]NotifyParameters apiParams)
        {
            var result = new ApiResult();

            if (ModelState.IsValid)
            {
                result.Success = await _mirrorService.Notify(apiParams.friendLight, apiParams.State, apiParams.Red, apiParams.Green, apiParams.Blue, apiParams.BrightnessPercent);
            }
            else
            {
                result.Success = false;
                result.Message = "That did not work :(\nFeel free to use our contact form to let us know.";
            };

            return result;
        }


        [Authorize(Policy = "Owners")]
        [HttpPost]
        [Route("SetRunMode")]
        public async Task<ApiResult> SetRunMode([FromBody]SetRunModeParameters apiParams)
        {
            var result = new ApiResult();

            if (ModelState.IsValid)
            {
                result.Success = await _mirrorService.SetRunMode(apiParams.runMode, apiParams.Red, apiParams.Green, apiParams.Blue, apiParams.BrightnessPercent);
            }
            else
            {
                result.Success = false;
                result.Message = "That did not work :(\nFeel free to use our contact form to let us know.";
            };

            return result;
        }

    }
}
