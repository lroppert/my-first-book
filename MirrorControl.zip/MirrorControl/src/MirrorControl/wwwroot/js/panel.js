﻿(function ($) {

    var lastColor;

    function updateSwitch(name, state, color) {

        if (state) {
            var brightness = "Brightness<br/>" + Math.round(tinycolor(color).getAlpha() * 100) + "%";
            $("[name='" + name + "']").bootstrapSwitch('labelText', brightness, true);

            var cBack = color.toHexString();
            if (color.getBrightness() > tinycolor('#f5f5f5').getBrightness()) {
                cBack = tinycolor('#f5f5f5').toHexString();
            }
            var cFore = tinycolor.mostReadable(color, ['#000', '#fff']).toHexString()

            $("[name='" + name + "']").parent().children().first().css("color", cFore).css("background", cBack);
        } else {
            $("[name='" + name + "']").bootstrapSwitch('labelText', ' ', true);
        }

    }


    function onFL1Switched(event, state) {
        //console.log("FL1 switched!");
        //console.log(this); // DOM element
        //console.log(event); // jQuery event
        //console.log(state); // true | false

        updateSwitch("fl1-switch", state, lastColor);
    }

    function onFL2Switched(event, state) {
        //console.log("FL2 switched!");
        //console.log(this); // DOM element
        //console.log(event); // jQuery event
        //console.log(state); // true | false

        updateSwitch("fl2-switch", state, lastColor);
    }

    function onColorChanged(container, color) {
        //console.log("Color changed!");
        //console.log(container);
        //console.log(color);

        lastColor = tinycolor(color.rgba);
    }

    function updateColor(evtToken) {
        var c = tinycolor(evtToken.substring(1, 7));
        c._a = parseInt("0x" + evtToken.substring(9)) / 255;
        //$("#colorPicker").trigger("colorpickersliders.updateColor", c);
        return c;
    }

    function update_fl1(notifyToken) {
        //console.log("Notify 1: " + notifyToken);

        var requiredState = false;

        if (notifyToken.startsWith("on_")) {
            requiredState = true;
            var c = updateColor(notifyToken.substring(notifyToken.indexOf("_") + 1));
        }
        $("[name='fl1-switch']").bootstrapSwitch('state', requiredState, true);
        updateSwitch("fl1-switch", requiredState, c);
    }


    function update_fl2(notifyToken) {
        //console.log("Notify 2: " + notifyToken);

        var requiredState = false;

        if (notifyToken.startsWith("on_")) {
            requiredState = true;
            var c = updateColor(notifyToken.substring(notifyToken.indexOf("_") + 1));
        }
        $("[name='fl2-switch']").bootstrapSwitch('state', requiredState, true);
        updateSwitch("fl2-switch", requiredState, c);
    }


    function update_mode(modeToken) {
        //console.log("Mode Update: " + modeToken);

        var modeInfo = -1;

        if (modeToken != "off") {
            var colorInfo = modeToken.substring(modeToken.indexOf("_") + 1);
            modeInfo = parseInt(modeToken.substring(0, modeToken.indexOf("_")));
            updateColor(colorInfo);
        }

        if (modeInfo == -1) {
            $('#mode label').eq(6).button('toggle').find(':checkbox').prop('checked');
        } else {
            $('#mode label').eq(modeInfo).button('toggle').find(':checkbox').prop('checked');
        }
    }


    function changeFriendLight(friendLight, state) {

        $.ajax({
            url: "api/mirror/v1/notify",
            type: "post",
            contentType: "application/json",
            headers: {
                Accept: "*/*",
                "Cache-Control": 'no-cache',
                "X-Requested-With": "XMLHttpRequest"
            },
            dataType: "json",
            data: JSON.stringify({
                FriendLight: friendLight,
                State: state,
                Red: lastColor._r,
                Green: lastColor._g,
                Blue: lastColor._b,
                BrightnessPercent: Math.round(lastColor._a * 100)
            }),
            success: function (data, textStatus, xhr) {
                //console.log("Notification sent successfully!");
                //console.log(data);
            },
            error: function (xhr, textStatus, errorThrown) {
                //console.log(errorThrown);
                if (xhr.status == 401) {
                    //console.log("Redirect to login...");
                    location.href = "/Account/Login";
                }
            }
        });

    }

    // === Initialize Color Picker ===

    $("#colorPicker").ColorPickerSliders({
        flat: true,
        sliders: true,
        swatches: ['FFFFFF', 'C0C0C0', '808080', '000000', 'FF0000', '800000', 'FFFF00', '808000', '00FF00', '008000', '00FFFF', '008080', '0000FF', '000080', 'FF00FF', '800080'],
        hsvpanel: true,
        grouping: false,
        order: {
            rgb: 1,
            opacity: 2,
            preview: 3
        },
        previewformat: 'hex',
        onchange: onColorChanged
    });
    // That initialization triggers also the onChange Event
    $("#colorPicker").trigger("colorpickersliders.updateColor", "rgba(255, 255, 255, 0.5)");

    $("[name='fl1-switch']").bootstrapSwitch();
    $("[name='fl2-switch']").bootstrapSwitch();
    $('input[name="fl1-switch"]').on('switchChange.bootstrapSwitch', onFL1Switched);
    $('input[name="fl2-switch"]').on('switchChange.bootstrapSwitch', onFL2Switched);


    // === Initialize Status ===


    $.ajax({
        url: "api/mirror/v1/status",
        type: "get",
        headers: {
            Accept: "*/*",
            "Cache-Control": 'no-cache',
            "X-Requested-With": "XMLHttpRequest"
        },
        success: function (status, textStatus, xhr) {
            //console.log("Status aquired successfully!");
            //console.log(status);

            update_mode(status.stripStatus);
            update_fl1(status.led1Status);
            update_fl2(status.led2Status);

        },
        error: function (xhr, textStatus, errorThrown) {
            //console.log(errorThrown);
            if (xhr.status == 401) {
                location.href = "/Account/Login";
            }
        }
    });






    // === Subscribe Eventstream ===

    var particle = new Particle();
    $.ajax({
        url: "api/mirror/v1/dc",
        type: "get",
        headers: {
            Accept: "*/*",
            "Cache-Control": "no-cache",
            "X-Requested-With": "XMLHttpRequest"
        },
        success: function (dc, textStatus, xhr) {
            //console.log("Token aquired successfully!");
            //console.log(dc);

            particle.getEventStream(dc).then(function (stream) {
                stream.on('event', function (data) {

                    //console.log("[" + data.name + "]");
                    //console.log(data.data);
                    //console.log(data.published_at);

                    if (data.name.toLowerCase() == "fl1") {
                        update_fl1(data.data);
                    }

                    if (data.name.toLowerCase() == "fl2") {
                        update_fl2(data.data);
                    }

                    if (data.name.toLowerCase() == "mode") {
                        update_mode(data.data);
                    }

                });
            });

        },
        error: function (xhr, textStatus, errorThrown) {
            //console.log(errorThrown);
            if (xhr.status == 401) {
                location.href = "/Account/Login";
            }
        }
    });





    // === Wiring Friendlight switches ===


    $('input[name="fl1-switch"]').on('switchChange.bootstrapSwitch', function (event, state) {
        //console.log(this); // DOM element
        //console.log(event); // jQuery event
        //console.log(state); // true | false

        //var $btn = $(this).button('loading')
        changeFriendLight("Led1", state);
        //$btn.button('reset')
    });

    $('input[name="fl2-switch"]').on('switchChange.bootstrapSwitch', function (event, state) {
        //console.log(this); // DOM element
        //console.log(event); // jQuery event
        //console.log(state); // true | false

        //var $btn = $(this).button('loading')
        changeFriendLight("Led2", state);
        //$btn.button('reset')
    });



    // === Wiring runmode controls ===

    $('#mode label').on("click", function () {
        //console.log("click fired");
        //console.log(this);

        var mode = $(this).attr("data-mode");

        //console.log(mode);

        $.ajax({
            url: "api/mirror/v1/setrunmode",
            type: "post",
            contentType: "application/json",
            headers: {
                Accept: "*/*",
                "Cache-Control": 'no-cache',
                "X-Requested-With": "XMLHttpRequest"
            },
            dataType: "json",
            data: JSON.stringify({
                RunMode: mode,
                Red: lastColor._r,
                Green: lastColor._g,
                Blue: lastColor._b,
                BrightnessPercent: Math.round(lastColor._a * 100)
            }),
            success: function (data, textStatus, xhr) {
                //console.log("Runmode set successfully!");
                //console.log(data);
            },
            error: function (xhr, textStatus, errorThrown) {
                //console.log(errorThrown);
                if (xhr.status == 401) {
                    location.href = "/Account/Login";
                }
            }
        });


    });


}($));