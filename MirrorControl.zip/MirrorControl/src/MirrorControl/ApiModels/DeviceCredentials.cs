﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MirrorControl.ApiModels
{
    public class DeviceCredentials
    {
        public string deviceId;
        public string auth;
    }
}

