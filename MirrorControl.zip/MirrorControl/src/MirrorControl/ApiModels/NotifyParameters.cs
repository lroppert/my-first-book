﻿using MirrorControl.Services;
using System.ComponentModel.DataAnnotations;

namespace MirrorControl.ApiModels
{
    public class NotifyParameters
    {
        [Required]
        [EnumDataType(typeof(FriendLight))]
        public FriendLight friendLight;

        [Required]
        public bool State;

        [Required]
        [Range(0, 255)]
        public byte Red;

        [Required]
        [Range(0, 255)]
        public byte Green;

        [Required]
        [Range(0, 255)]
        public byte Blue;

        [Required]
        [Range(0, 255)]
        public byte BrightnessPercent;
    }
}
