﻿using MirrorControl.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MirrorControl.ApiModels
{
    public class SetRunModeParameters
    {
        [Required]
        [EnumDataType(typeof(RunMode))]
        public RunMode runMode;

        [Required]
        [Range(0, 255)]
        public byte Red;

        [Required]
        [Range(0, 255)]
        public byte Green;

        [Required]
        [Range(0, 255)]
        public byte Blue;

        [Required]
        [Range(0, 255)]
        public byte BrightnessPercent;
    }
}
